int row0[3];
int row1[3];
int row2[3];
int row3[3];
int row4[3];
int row5[3];
int row6[3];
int row7[3];
int row8[3];
int row9[3];
int row10[5];
int row11[3];
int row12[3];
int row13[3];
int row14[3];
int row15[3];
int row16[3];
int row17[3];
int row18[3];
int row19[3];
int row20[3];
int row21[3];
int row22[3];
int row23[3];
int row24[3];
int row25[3];
int row26[3];
int row27[3];
int row28[3];
int row29[3];
int row30[3];
int row31[3];
int row32[3];


int *action[33];

int goto0[5];
int goto4[5];
int goto7[3];
int goto8[5];
int goto12[3];
int goto16[3];
int goto17[3];

int *goto_table[33];

int lhs[9];

int reduce[9];

int next(int **table, int cur_state, int symbol);

void generate(int reduction);
int peek(int stack[]);
void push(int stack[], int d);
int pop(int stack[]);